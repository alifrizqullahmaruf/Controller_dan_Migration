window.onload = function() {
    alert("Selamat datang pada halaman About");
};