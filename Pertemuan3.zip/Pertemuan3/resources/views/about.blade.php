<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>About</title>
    <!-- Tambahkan link ke Bootstrap CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Gunakan kelas "container" untuk membuat tampilan terpusat -->
    <div class="container">
        <h1 class="mt-5 display-2 text-center">Halaman About</h1>
        <div class="mt-4">
            <!-- Gunakan kelas "card" untuk tampilan kotak dengan bayangan -->
            <div class="card">
                <div class="card-body display text-center">
                    <!-- Menggunakan grid untuk menyusun elemen-elemen -->
                    <figure class="figure">
                        <img src="https://i.pinimg.com/564x/d0/84/17/d084175de7c21542d0999b43ce595535.jpg" class="figure-img img-fluid rounded-circle" alt="Foto Profil">
                    </figure>
                    <br>
                    <h3 class="card-title"><?= $name ?></h3>
                    <br>
                    <h3 class="card-subtitle mb-2 text-muted"><?= $email ?></h3>
                    <br>
                    <h3 class="card-text"><?= $umur ?></h3>
                    <br>
                    <h3 class="card-text"><?= $hobi ?></h3>
                    <br>
                    <h3 class="card-text"><?= $alamat ?></h3>
                </div>                
            </div>
        </div>
    </div>
    
    <!-- Tambahkan script Bootstrap JavaScript (JQuery diperlukan) -->
    <script src="js/app/js"></script>
    <script>
            window.onload = function() {
        alert("Selamat datang pada halaman About");
    };
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
